import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.List;

public class MultiJVMQServiceVerifier {

    public static void main(String[] args) {
        String directory = args[0];
        String outFileName = args[1];
        String outFileName1 = null;
        if (args.length > 2)
            outFileName1 = args[2];
        String[] files = null;
        if (outFileName1 != null)
            files = new String[] { outFileName, outFileName1 };
        else
            files = new String[] { outFileName };

        List<String> allMessagesProduced = new ArrayList<String>();
        List<String> allMessagesConsumed = new ArrayList<String>();

        for (String fileN : files) {
            FileInputStream fin = null;
            ObjectInputStream oin = null;
            try {
                fin = new FileInputStream(new File(directory + File.separator
                        + fileN + ".produced"));
                oin = new ObjectInputStream(fin);
                allMessagesProduced.addAll((List<String>) (oin.readObject()));
            } catch (Throwable t) {
                t.printStackTrace();
            } finally {
                if (oin != null)
                    try {
                        oin.close();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                if (fin != null)
                    try {
                        fin.close();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
            }
            fin = null;
            oin = null;
            try {
                fin = new FileInputStream(new File(directory + File.separator
                        + fileN + ".consumed"));
                oin = new ObjectInputStream(fin);
                allMessagesConsumed.addAll((List<String>) (oin.readObject()));
            } catch (Throwable t) {
                t.printStackTrace();
            } finally {
                if (oin != null)
                    try {
                        oin.close();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                if (fin != null)
                    try {
                        fin.close();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
            }
        }
        boolean sameSize = (allMessagesProduced.size() == allMessagesConsumed
                .size());
        assert sameSize;
        System.out.println("Size : " + sameSize);
        boolean sameContents = (allMessagesProduced.equals(allMessagesConsumed));
        assert sameContents;
        System.out.println("SameConten : " + sameContents);

        System.exit(0);
    }
}
