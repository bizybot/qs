#!/bin/bash

#!/bin/bash

CURRENT_DIR=$PWD

echo $CURRENT_DIR

MAVEN_PROJECT_CANVA_CHALLENGE=canva-queue-challenge
MAVEN_PROJECT_USE_QS=use-queue-service
MAVEN_PROJECT_FQ_VERIFY=fq-service-verifier

dir=$CURRENT_DIR'/'$MAVEN_PROJECT_CANVA_CHALLENGE
cd $dir
mvn clean

dir=$CURRENT_DIR'/'$MAVEN_PROJECT_USE_QS
cd $dir
mvn clean

dir=$CURRENT_DIR'/'$MAVEN_PROJECT_FQ_VERIFY
cd $dir
mvn clean

