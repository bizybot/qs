import java.util.ArrayList;
import java.util.List;

public class MessageConsumedInfo {

    List<String> messages = new ArrayList<String>();

}
