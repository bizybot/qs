import java.util.Random;
import java.util.concurrent.Callable;

import com.example.model.Identifier;
import com.example.model.message.Message;
import com.example.model.message.MessageSendRequest.MessageSendRequestBuilder;
import com.example.service.QueueService;

public class MessageProducer implements Callable<MessageProducedInfo> {
    private int startProdMsgCount = 0;
    private int endProdMsgCount = 0;
    private QueueService qs = null;
    private Identifier qid;

    public MessageProducer(int start, int end, QueueService qs, Identifier qid) {
        startProdMsgCount = start;
        endProdMsgCount = end;
        this.qs = qs;
        this.qid = qid;
    }

    public MessageProducedInfo call() throws Exception {

        MessageProducedInfo info = new MessageProducedInfo();

        for (int i = startProdMsgCount; i < endProdMsgCount; i++) {
            String msgPayload = "MSG-" + i;
            qs.sendMessage(new MessageSendRequestBuilder().withMesage(
                    new Message.MessageBuilder().withQueueId(qid)
                            .withMessagePayload(msgPayload).build()).build());
            info.messages.add(msgPayload);
            try {
                Thread.sleep(new Random().nextInt(1000));
            } catch (InterruptedException e) {

            }
        }

        return info;
    }

}
