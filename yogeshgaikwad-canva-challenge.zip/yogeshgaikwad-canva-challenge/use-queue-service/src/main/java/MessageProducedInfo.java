import java.util.ArrayList;
import java.util.List;

public class MessageProducedInfo {

    List<String> messages = new ArrayList<String>();

}
