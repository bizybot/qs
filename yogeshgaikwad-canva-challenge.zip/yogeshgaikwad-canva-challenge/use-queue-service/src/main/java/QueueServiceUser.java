import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import com.example.model.Identifier;
import com.example.model.queue.QueueAttributeKeys;
import com.example.model.queue.QueueConfig;
import com.example.service.QueueService;
import com.example.service.impl.file.FileQueueService;
import com.example.service.impl.file.model.FileQueueManager;

public class QueueServiceUser {

    private static ExecutorService executor = Executors.newFixedThreadPool(10);

    public static void main(String[] args) {

        if (args.length < 5) {
            System.out
                    .println("Args : dbDirectory start end outFileName countTill");
            System.exit(-1);
        }

        String dbDirectory = args[0];
        int startProdMsgCount = Integer.parseInt(args[1]);
        int endProdMsgCount = Integer.parseInt(args[2]);
        String outFile = args[3];
        int countTill = Integer.parseInt(args[4]);

        QueueService queueService = new FileQueueService(new FileQueueManager(
                dbDirectory, "fileQ.db"));

        Identifier identifier = null;
        List<Identifier> queues = queueService.listQueues();
        if (queues.isEmpty()) {
            try {
                // Sleep for some time then check
                Thread.sleep(new Random().nextInt(10000));
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

            queues = queueService.listQueues();
            if (queues.isEmpty()) {
                // Still empty
                QueueConfig qConfig = new QueueConfig.QueueConfigBuilder()
                        .withQueueName("Q1")
                        .addAttribute(QueueAttributeKeys.VISIBILITY_TIMEOUT,
                                "1000").build();

                identifier = queueService.createQueue(qConfig);
            } else {
                identifier = queues.get(0);
            }
        } else {
            identifier = queues.get(0);
        }

        Future<MessageProducedInfo> futureMsgProduced = executor
                .submit(new MessageProducer(startProdMsgCount, endProdMsgCount,
                        queueService, identifier));

        Future<MessageConsumedInfo> futureMsgConsumed = executor
                .submit(new MessageConsumer(queueService, identifier, countTill));

        executor.shutdown();
        try {
            executor.awaitTermination(Long.MAX_VALUE, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        if (futureMsgProduced.isDone()) {
            FileOutputStream fos = null;
            ObjectOutputStream oos = null;
            try {
                System.out.println("Produced Count : "
                        + futureMsgProduced.get().messages.size());

                fos = new FileOutputStream(dbDirectory + File.separator
                        + outFile + ".produced");
                oos = new ObjectOutputStream(fos);
                oos.writeObject(futureMsgProduced.get().messages);
                oos.flush();
            } catch (Throwable e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } finally {
                if (oos != null)
                    try {
                        oos.close();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                if (fos != null)
                    try {
                        fos.close();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
            }
        }

        if (futureMsgConsumed.isDone()) {
            FileOutputStream fos = null;
            ObjectOutputStream oos = null;
            try {
                System.out.println("Consumed Count : "
                        + futureMsgConsumed.get().messages.size());

                fos = new FileOutputStream(dbDirectory + File.separator
                        + outFile + ".consumed");
                oos = new ObjectOutputStream(fos);
                oos.writeObject(futureMsgProduced.get().messages);
                oos.flush();
            } catch (Throwable e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } finally {
                if (oos != null)
                    try {
                        oos.close();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                if (fos != null)
                    try {
                        fos.close();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
            }
        }
        System.exit(0);
    }
}
