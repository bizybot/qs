import java.util.concurrent.Callable;

import com.example.model.Identifier;
import com.example.model.QueueMetaData;
import com.example.model.message.Message;
import com.example.service.QueueService;

public class MessageConsumer implements Callable<MessageConsumedInfo> {

    private QueueService qs = null;
    private Identifier qid;
    private int countTill = 100;

    public MessageConsumer(QueueService qs, Identifier qid, int countTill) {

        this.qs = qs;
        this.qid = qid;
        this.countTill = countTill;
    }

    public MessageConsumedInfo call() throws Exception {
        MessageConsumedInfo info = new MessageConsumedInfo();

        int continousEmptyCounts = 0;

        for (; continousEmptyCounts < countTill;) {
            System.out
                    .println("continousEmptyCounts = " + continousEmptyCounts);
            Message message = qs.receiveMessage(qid);
            if (message == null) {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {

                }
                QueueMetaData qmd = qs.getQueueMetaData(qid);
                if (qmd.getTotalUnprocessedMessagesCount() == 0
                        && qmd.getTotalInvisibleMessagesCount() == 0) {
                    continousEmptyCounts++;
                } else {
                    continousEmptyCounts = 0;
                }

                continue;
            }
            qs.deleteMessage(qid, message.getMessageReceiptHandle());
            String msgPayload = message.getMessagePayload();
            info.messages.add(msgPayload);

            QueueMetaData qmd = qs.getQueueMetaData(qid);
            if (qmd == null) {
                // Why is it null
                System.out.println("Queue metadata is null ????");
            }
            if (qmd.getTotalUnprocessedMessagesCount() == 0
                    && qmd.getTotalInvisibleMessagesCount() == 0) {
                continousEmptyCounts++;
            } else {
                continousEmptyCounts = 0;
            }
        }

        return info;
    }

}
