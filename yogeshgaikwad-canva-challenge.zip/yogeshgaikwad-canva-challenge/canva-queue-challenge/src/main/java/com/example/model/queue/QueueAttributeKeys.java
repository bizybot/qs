package com.example.model.queue;

/**
 * This class defines all available Queue attributes.
 * These attributes are in place attributes to what SQS provides.
 */
public enum QueueAttributeKeys {

    /**
     * Message visibility timeout
     */
    VISIBILITY_TIMEOUT("VisibilityTimeout", DataType.LONG),

    ;

    private String sqsQueueAttributeKey;
    private DataType type;

    QueueAttributeKeys(String messageAttributeKey, DataType type) {
        this.sqsQueueAttributeKey = messageAttributeKey;
        this.type = type;
    }

    public String getSqsQueueAttributeKey() {
        return sqsQueueAttributeKey;
    }

    public DataType getType() {
        return type;
    }

    public static enum DataType {
        STRING,
        LONG
    }
}
