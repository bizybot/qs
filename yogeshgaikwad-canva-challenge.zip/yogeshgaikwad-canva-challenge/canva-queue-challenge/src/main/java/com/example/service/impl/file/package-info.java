/**
 * This package contains of all model and implementation classes for File based Queue Service.
 */
package com.example.service.impl.file;