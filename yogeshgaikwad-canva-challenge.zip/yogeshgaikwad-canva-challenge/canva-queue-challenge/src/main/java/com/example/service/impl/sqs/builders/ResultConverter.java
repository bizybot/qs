package com.example.service.impl.sqs.builders;

import com.amazonaws.services.sqs.model.CreateQueueResult;
import com.example.model.Identifier;

public class ResultConverter {

    public Identifier convertCreateQueueResult(CreateQueueResult result) {
        return new Identifier(result.getQueueUrl());
    }
}
