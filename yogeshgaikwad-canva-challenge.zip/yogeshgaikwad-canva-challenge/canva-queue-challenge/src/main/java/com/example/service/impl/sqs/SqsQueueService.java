package com.example.service.impl.sqs;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.amazonaws.services.sqs.AmazonSQSClient;
import com.amazonaws.services.sqs.model.CreateQueueResult;
import com.amazonaws.services.sqs.model.ListQueuesResult;
import com.amazonaws.services.sqs.model.MessageAttributeValue;
import com.amazonaws.services.sqs.model.ReceiveMessageRequest;
import com.amazonaws.services.sqs.model.ReceiveMessageResult;
import com.example.model.Identifier;
import com.example.model.QueueMetaData;
import com.example.model.message.Message;
import com.example.model.message.Message.MessageBuilder;
import com.example.model.message.MessageSendRequest;
import com.example.model.queue.QueueConfig;
import com.example.service.QueueService;
import com.example.service.impl.sqs.builders.CreateQueueRequestBuilder;
import com.example.service.impl.sqs.builders.ResultConverter;
import com.example.service.impl.sqs.builders.SendMessageRequestBuilder;
import com.example.utils.BasicLogger;

/**
 * SQS queue service implementation.
 * <pre>
 * Note: Requires SQS credentials to execute.
 * </pre>
 */
public class SqsQueueService implements QueueService {
    private static BasicLogger logger = BasicLogger.getLogger();
    private AmazonSQSClient sqsClient;

    public SqsQueueService(AmazonSQSClient sqsClient) {
        this.sqsClient = sqsClient;
    }

    public Identifier createQueue(QueueConfig queueConfig) {
        logger.log("Create Queue : "+queueConfig);
        // Create Queue
        CreateQueueResult result = sqsClient
                .createQueue(new CreateQueueRequestBuilder(queueConfig).build());

        return new ResultConverter().convertCreateQueueResult(result);
    }

    public void deleteQueue(Identifier identifier) {
        logger.log("Delete queue : "+identifier);
        this.sqsClient.deleteQueue(identifier.getId());
    }

    public void sendMessage(MessageSendRequest messageSendRequest) {
        logger.log("Send message : "+messageSendRequest);
        this.sqsClient.sendMessage(new SendMessageRequestBuilder(
                messageSendRequest).build());
    }

    public void deleteMessage(Identifier queueIdentifier,
            Identifier messageReceiptHandle) {
        logger.log("Delete message : qid : "+queueIdentifier+", msgreceipthandle :" + messageReceiptHandle);
        this.sqsClient.deleteMessage(queueIdentifier.getId(),
                messageReceiptHandle.getId());

    }

    public List<Identifier> listQueues() {
        logger.log("List queues");
        ListQueuesResult results = this.sqsClient.listQueues();
        List<Identifier> qids = new ArrayList<Identifier>();
        if (results.getQueueUrls() != null && !results.getQueueUrls().isEmpty()) {

            for (String url : results.getQueueUrls()) {
                qids.add(new Identifier(url));
            }
        }
        return qids;
    }

    public Message receiveMessage(Identifier queueId) {
        logger.log("Receive message");
        // Create request
        ReceiveMessageRequest request = new ReceiveMessageRequest(
                queueId.getId());
        request.setMaxNumberOfMessages(1);
        request.setMessageAttributeNames(Arrays.asList(new String[]{"All"}));

        // Receive message
        ReceiveMessageResult result = this.sqsClient.receiveMessage(request);
        List<com.amazonaws.services.sqs.model.Message> msgs = result
                .getMessages();
        if (msgs.isEmpty())
            return null;
        // TODO Needs converter instead of this code.
        // Convert to message
        Message message = new MessageBuilder().withQueueId(queueId)
                .withMessagePayload(msgs.get(0).getBody()).build();
        message.setMessageIdentifier(new Identifier(msgs.get(0).getMessageId()));
        message.setMessageReceiptHandle(new Identifier(msgs.get(0)
                .getReceiptHandle()));

        // Fill attributes
        Map<String, String> messageAttributes = new HashMap<>();
        Map<String, MessageAttributeValue> msgAttributes = msgs.get(0)
                .getMessageAttributes();
        for (Entry<String, MessageAttributeValue> entry : msgAttributes
                .entrySet()) {
            messageAttributes.put(entry.getKey(), entry.getValue()
                    .getStringValue());
        }
        message.setMessageAttributes(messageAttributes);

        return message;
    }

    public void deleteAllQueues() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException();
    }

    @Override
    public QueueMetaData getQueueMetaData(Identifier queueIdentifier) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException();
    }
}
