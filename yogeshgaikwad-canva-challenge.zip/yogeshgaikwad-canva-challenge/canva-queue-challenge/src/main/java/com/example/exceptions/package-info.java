/**
 * This package contains of all exceptions within the project.
 * All the exceptions are Runtime exceptions.
 */
package com.example.exceptions;