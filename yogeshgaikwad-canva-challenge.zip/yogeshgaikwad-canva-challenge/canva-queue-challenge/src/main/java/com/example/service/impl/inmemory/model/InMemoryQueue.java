package com.example.service.impl.inmemory.model;

import java.io.Serializable;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.concurrent.BlockingDeque;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingDeque;

import com.example.model.Identifier;
import com.example.model.message.Message;
import com.example.model.queue.MessageQueue;
import com.example.model.queue.QueueAttributeKeys;
import com.example.model.queue.QueueConfig;
import com.example.utils.BasicLogger;

/**
 * Thread safe implementation for Message Queue.
 */
public class InMemoryQueue implements MessageQueue {
    private static final long serialVersionUID = 1L;

    private static BasicLogger logger = BasicLogger.getLogger();

    private QueueConfig queueConfig;
    private BlockingDeque<Message> messages = new LinkedBlockingDeque<Message>();
    private ConcurrentHashMap<Identifier, MessageEntry> chmInvisibleMessages = new ConcurrentHashMap<Identifier, MessageEntry>();

    public InMemoryQueue(QueueConfig queueConfig) {
        this.queueConfig = queueConfig;
    }

    public QueueConfig getQueueConfig() {
        return queueConfig;
    }

    public void setQueueConfig(QueueConfig queueConfig) {
        this.queueConfig = queueConfig;
    }

    public boolean offerFirst(Message message) {
        return messages.offerFirst(message);
    }

    public boolean offer(Message message) {
        return messages.offerLast(message);
    }

    public Message poll() {
        Message message = messages.pollFirst();
        if (message == null)
            return null;

        Message messageRetVal = new Message.MessageBuilder()
                .newMessageHandle(message);

        // Make invisible
        makeMessageInvisible(messageRetVal);

        return messageRetVal;
    }

    private void makeMessageInvisible(Message messageRetVal) {
        // Make it invisible
        long visibileTimeout = Long.parseLong(queueConfig.getQueueAttributes()
                .get(QueueAttributeKeys.VISIBILITY_TIMEOUT));
        MessageEntry entry = new MessageEntry(messageRetVal, visibileTimeout);
        chmInvisibleMessages
                .put(messageRetVal.getMessageReceiptHandle(), entry);
    }

    public void remove(Identifier messageReceiptHandle) {
        chmInvisibleMessages.remove(messageReceiptHandle);
    }

    public void handleMessageTimeout() {
        Iterator<Entry<Identifier, MessageEntry>> iter = chmInvisibleMessages
                .entrySet().iterator();
        for (; iter.hasNext();) {
            Entry<Identifier, MessageEntry> entry = iter.next();
            if (entry.getValue().hasExpired()) {
                // Expired
                iter.remove();
                // Add at first
                messages.offerFirst(entry.getValue().message);
            }
        }

    }

    private static class MessageEntry implements Serializable {
        private static final long serialVersionUID = 1L;
        private Message message;
        private long expireAt;

        public MessageEntry(Message message, long visibilityTimeout) {
            this.message = message;
            this.expireAt = System.currentTimeMillis() + visibilityTimeout;
            logger.log("Message entry " + message.getMessageReceiptHandle()
                    + " > " + this.expireAt);
        }

        /**
         * Checks if message entry has expired.
         * [Current time >= ExpireAt]
         * @return <code>true</code> if it has expired else <code>false</code>
         */
        boolean hasExpired() {
            if (System.currentTimeMillis() >= this.expireAt) {
                logger.log("Expired : " + message.getMessageReceiptHandle());
                return true;
            }
            logger.log("Not Expired " + message.getMessageReceiptHandle()
                    + " > " + (System.currentTimeMillis() - expireAt));
            return false;
        }

        @Override
        public int hashCode() {
            final int prime = 31;
            int result = 1;
            result = prime * result
                    + ((message == null) ? 0 : message.hashCode());
            result = prime * result + (int) (expireAt ^ (expireAt >>> 32));
            return result;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj)
                return true;
            if (obj == null)
                return false;
            if (getClass() != obj.getClass())
                return false;
            MessageEntry other = (MessageEntry) obj;
            if (message == null) {
                if (other.message != null)
                    return false;
            } else if (!message.equals(other.message))
                return false;
            if (expireAt != other.expireAt)
                return false;
            return true;
        }
    }

    @Override
    public long getUnprocessedMessageCount() {
        return messages.size();
    }

    @Override
    public long getInvisibleMessageCount() {
        return chmInvisibleMessages.size();
    }
}
