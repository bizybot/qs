package com.example.model.queue;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import com.example.exceptions.InvalidArgumentException;

/**
 * This class is used for accepting Queue configuration parameters.
 */
public class QueueConfig implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * Queue Name
     */
    private String queueName;

    /**
     * Queue configuration attributes.
     * <pre>
     * <bold>{@link QueueAttributeKeys#VISIBILITY_TIMEOUT}</bold> : 
     *          Message visibility timeout in milliseconds. Default 1 minute (60000), value range [0-60*60*1000]
     *          When queue message is consumed it is not immediately removed from queue.
     *          For this configured time, it remains invisible.
     *          Within this timeout period the consumer has to delete the message by
     *          using receipt handle of the message.
     *          If not done then the message is added in front to the queue.
     * Note:
     *      New additional attributes can be added to this when supported in future.
     * </pre>
     * @see QueueAttributeKeys
     */
    private Map<QueueAttributeKeys, String> queueAttributes;

    private QueueConfig() {
        this.queueAttributes = new HashMap<QueueAttributeKeys, String>();
    }

    private QueueConfig(String qName) {
        this.queueName = qName;
    }

    /**
     * @return Queue Name
     */
    public String getQueueName() {
        return queueName;
    }

    public void setQueueName(String qName) {
        this.queueName = qName;
    }

    public Map<QueueAttributeKeys, String> getQueueAttributes() {
        return queueAttributes;
    }

    /**
     * QueueConfiguration additional attributes
     * {@link QueueAttributeKeys}
     * @param queueAttributes
     */
    public void setQueueAttributes(
            Map<QueueAttributeKeys, String> queueAttributes) {
        this.queueAttributes = queueAttributes;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result
                + ((queueAttributes == null) ? 0 : queueAttributes.hashCode());
        result = prime * result
                + ((queueName == null) ? 0 : queueName.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        QueueConfig other = (QueueConfig) obj;
        if (queueAttributes == null) {
            if (other.queueAttributes != null)
                return false;
        } else if (!queueAttributes.equals(other.queueAttributes))
            return false;
        if (queueName == null) {
            if (other.queueName != null)
                return false;
        } else if (!queueName.equals(other.queueName))
            return false;
        return true;
    }

    @Override
    public String toString() {
        return "QueueConfig [queueName=" + queueName + ", queueAttributes="
                + queueAttributes + "]";
    }

    /**
     * This class is used to build queue configuration.
     */
    public static class QueueConfigBuilder {

        /**
         * Queue Name
         */
        private String qName;

        /**
         * QueueAttributes
         */
        private Map<QueueAttributeKeys, String> queueAttributes = new HashMap<QueueAttributeKeys, String>();

        /**
         * Build QueueConfig object
         * @return Instance of {@link QueueConfig}
         */
        public QueueConfig build() {
            QueueConfig qc = new QueueConfig(qName);
            if (!queueAttributes
                    .containsKey(QueueAttributeKeys.VISIBILITY_TIMEOUT)) {
                addAttribute(QueueAttributeKeys.VISIBILITY_TIMEOUT, "60000");
            }

            qc.setQueueAttributes(queueAttributes);
            return qc;

        }

        /**
         * Queue Name
         * @param qName Queue name
         * @return {@link QueueConfigBuilder}
         */
        public QueueConfigBuilder withQueueName(String qName) {
            this.qName = qName;
            return this;
        }

        /**
         * Add Queue configuration attribute.
         * <pre>
         * <bold>{@link QueueAttributeKeys#VISIBILITY_TIMEOUT}</bold> : 
         *          Message visibility timeout in milliseconds. Default 1 minute (60000), value range [0-60*60*1000]
         *          When queue message is consumed it is not immediately removed from queue.
         *          For this configured time, it remains invisible.
         *          Within this timeout period the consumer has to delete the message by
         *          using receipt handle of the message.
         *          If not done then the message is added in front to the queue.
         * Note:
         *      New additional attributes can be added to this when supported in future.
         * </pre>
         * 
         * @param key {@link QueueAttributeKeys}
         * @param value value for the queue attribute
         * @return {@link QueueConfigBuilder}
         */
        public QueueConfigBuilder addAttribute(QueueAttributeKeys key,
                String value) {
            this.queueAttributes.put(key, value);
            switch (key.getType()) {
            case STRING:
                break;
            case LONG:
                try {
                    long val = Long.parseLong(value);
                    if (val < 0 || val > 3600000)
                        throw new InvalidArgumentException(key.toString(),
                                "Should be a long value Default 60000 Range[0 - 3600000]");
                } catch (NumberFormatException nbe) {
                    throw new InvalidArgumentException(key.toString(),
                            "Should be a long value Default 60000 Range[0 - 3600000]");
                }
                break;
            default:
                break;
            }
            return this;
        }
    }
}
