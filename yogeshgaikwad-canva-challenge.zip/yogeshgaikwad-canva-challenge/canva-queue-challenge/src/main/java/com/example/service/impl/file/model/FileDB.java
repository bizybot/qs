package com.example.service.impl.file.model;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.channels.FileChannel;
import java.util.HashMap;

import com.example.model.Identifier;
import com.example.utils.BasicLogger;

/**
 * This class manages file updates for queue operations in case of File based queue service.
 */
public class FileDB {
    private static BasicLogger logger = BasicLogger.getLogger();
    private HashMap<Identifier, FileQueue> hmQueues = new HashMap<Identifier, FileQueue>();

    private File dbFile;
    private File dbBackupFile;
    private File dbTempFile;

    /**
     * Constructor
     * @param dbFileN DB file path.
     */
    public FileDB(String dbFileN) {
        this.dbFile = new File(dbFileN);
        // backup file
        this.dbBackupFile = new File(dbFileN + ".backup");
        // temp file
        this.dbTempFile = new File(dbFileN + ".temp");
        try {
            // if db file does not exist then create
            if (!dbFile.exists()) {
                logger.log("Create new DB file : "+dbFileN);
                dbFile.createNewFile();
            } else {
                logger.log("De serialize from existing file");
                // De-serialize whatever is in the file
                hmQueues = deserialize();
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * @return hashmap of identifier to FileQueue.
     */
    public HashMap<Identifier, FileQueue> hashMap() {
        if (hmQueues == null || hmQueues.isEmpty()) {
            hmQueues = deserialize();
        }
        return hmQueues;
    }

    /**
     * Commit changes to file
     */
    public void commit() {
        logger.log("Commit changes to DB file");
        // creates temp file
        serialize();

        // Take backup
        copyFile(dbFile, dbFile);

        // Delete existing db file
        if (dbFile.exists())
            dbFile.delete();
        // Copy temp to db file.
        copyFile(dbTempFile, dbFile);

        // Delete backup file and temp file
        if (dbBackupFile.exists()) {
            dbBackupFile.delete();
        }
        if (dbTempFile.exists()) {
            dbTempFile.delete();
        }
    }

    // rollback is like deserializing from current db file.
    public void rollback() {
        // Discard changes in current map
        hmQueues = deserialize();
    }

    /**
     * Close just clears all the information in queue
     */
    public void close() {
        hmQueues.clear();
    }

    /**
     * Serialize to temp file
     */
    private void serialize() {
        logger.log("Serialize to DB temp file");
        FileOutputStream fos = null;
        ObjectOutputStream oos = null;
        try {
            fos = new FileOutputStream(dbTempFile);
            oos = new ObjectOutputStream(fos);
            oos.writeObject(hmQueues);
        } catch (Throwable t) {
            t.printStackTrace();
        } finally {
            try {
                if (oos != null) {
                    oos.flush();
                    oos.close();
                }
            } catch (IOException e) {
            }
            try {
                if (fos != null)
                    fos.close();
            } catch (IOException e) {
            }
        }

    }

    /**
     * De serialize from file.
     * @return {@link HashMap<String, FileQueue>}
     */
    private HashMap<Identifier, FileQueue> deserialize() {
        logger.log("De Serialize from DB file");
        FileInputStream fis = null;
        ObjectInputStream ois = null;
        try {
            fis = new FileInputStream(dbFile);
            if (fis.available() > 0) {
                ois = new ObjectInputStream(fis);
                return (HashMap<Identifier, FileQueue>) ois.readObject();
            }
        } catch (Throwable t) {
            t.printStackTrace();
        } finally {
            try {
                if (ois != null)
                    ois.close();
            } catch (IOException e) {
            }
            try {
                if (fis != null)
                    fis.close();
            } catch (IOException e) {
            }
        }

        return new HashMap<Identifier, FileQueue>();
    }

    /**
     * Copy file from source to destination
     * @param sourceFile Source File {@link File}
     * @param destFile Destination file {@link File}
     */
    public static void copyFile(File sourceFile, File destFile) {

        FileChannel source = null;
        FileChannel destination = null;
        try {
            // Destination file does not exist then create new.
            if (!destFile.exists()) {
                destFile.createNewFile();
            }
            logger.log("Copy source "+sourceFile.getAbsolutePath()+" to destination "+ destFile.getAbsolutePath() );
            // Source channel to destination channel transfer
            source = new FileInputStream(sourceFile).getChannel();
            destination = new FileOutputStream(destFile).getChannel();
            destination.transferFrom(source, 0, source.size());
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (source != null) {
                try {
                    source.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (destination != null) {
                try {
                    destination.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
