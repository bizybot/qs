package com.example.exceptions;

/**
 * This exception class is used to throw exceptions when object creation fails
 */
public class ObjectCreationFailedException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public ObjectCreationFailedException(String message, Throwable t) {
        super(message, t);
    }
}
