/**
 * This package contains of all model and implementation classes for In memory Queue Service.
 */
package com.example.service.impl.inmemory;