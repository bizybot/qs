/**
 * This package contains utility classes.
 */
package com.example.utils;