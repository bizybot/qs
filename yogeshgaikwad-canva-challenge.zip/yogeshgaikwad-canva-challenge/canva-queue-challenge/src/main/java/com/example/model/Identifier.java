package com.example.model;

import java.io.Serializable;

/**
 * This class is used to create unique Identifiers for various objects in the system.
 * <pre>
 * Constructs string based identifier.
 * This class can be used for any identifier type like UUID string or URL in case of SQS etc.
 * </pre>
 */
public class Identifier implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * Actual unique string representation of identifier.
     */
    private String id;

    /**
     * Constructs Identifier for given string Id.
     * @param id string identifier.
     */
    public Identifier(String id) {
        super();
        this.id = id;
    }

    /**
     * @return string Id
     */
    public String getId() {
        return id;
    }

    /**
     * Sets string id.
     * @param id string id
     */
    public void setId(final String id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Identifier other = (Identifier) obj;
        if (id == null) {
            if (other.id != null) {
                return false;
            }
        } else if (!id.equals(other.id)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return id;
    }

}
