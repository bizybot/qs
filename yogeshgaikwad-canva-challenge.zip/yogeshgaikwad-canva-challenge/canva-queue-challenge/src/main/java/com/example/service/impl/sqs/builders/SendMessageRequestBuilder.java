package com.example.service.impl.sqs.builders;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import com.amazonaws.services.sqs.model.MessageAttributeValue;
import com.amazonaws.services.sqs.model.SendMessageRequest;
import com.example.model.message.MessageSendRequest;

public class SendMessageRequestBuilder {
    private SendMessageRequest request = new SendMessageRequest();

    public SendMessageRequestBuilder(MessageSendRequest messageSendRequest) {
        request.setQueueUrl(messageSendRequest.getMessage()
                .getMessageQueueIdentifier().getId());
        request.setMessageBody(messageSendRequest.getMessage()
                .getMessagePayload());

        Map<String, MessageAttributeValue> mesMap = new HashMap<String, MessageAttributeValue>();
        for (Entry<String, String> entry : messageSendRequest.getMessage()
                .getMessageAttributes().entrySet()) {
            mesMap.put(entry.getKey(), new MessageAttributeValue().withDataType("String")
                    .withStringValue(entry.getValue()));
        }
        request.setMessageAttributes(mesMap);

    }

    public SendMessageRequest build() {
        return request;
    }

}
