/**
 * This package contains of all model and implementation classes for SQS based Queue Service.
 */
package com.example.service.impl.sqs;