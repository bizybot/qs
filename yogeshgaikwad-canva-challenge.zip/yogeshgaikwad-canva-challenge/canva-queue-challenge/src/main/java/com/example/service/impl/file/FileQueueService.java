package com.example.service.impl.file;

import java.util.List;
import java.util.UUID;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import com.example.model.Identifier;
import com.example.model.QueueMetaData;
import com.example.model.message.Message;
import com.example.model.message.MessageSendRequest;
import com.example.model.queue.QueueAttributeKeys;
import com.example.model.queue.QueueConfig;
import com.example.service.QueueService;
import com.example.service.impl.file.model.FileQueue;
import com.example.service.impl.file.model.FileQueueManager;
import com.example.utils.BasicLogger;

/**
 * Implements File based QueueService.
 */
public class FileQueueService implements QueueService {
    private static BasicLogger logger = BasicLogger.getLogger();

    private FileQueueManager fileQMgr;

    /**
     * Single Thread Executor.
     */
    private ScheduledExecutorService executorService = Executors
            .newScheduledThreadPool(100);

    public FileQueueService(FileQueueManager fileDB) {
        this.fileQMgr = fileDB;
    }

    public Identifier createQueue(QueueConfig queueConfig) {
        logger.log("Create Queue " + queueConfig);
        Identifier id = new Identifier(UUID.randomUUID().toString());
        FileQueue fileQueue = new FileQueue(queueConfig);

        fileQMgr.put(id, fileQueue);

        return id;
    }

    public void deleteQueue(Identifier queueId) {
        logger.log("Delete Queue with Id : " + queueId);
        fileQMgr.remove(queueId);
    }

    public void sendMessage(MessageSendRequest messageSendRequest) {
        logger.log("Send Message : " + messageSendRequest);
        fileQMgr.offer(messageSendRequest.getMessage());
    }

    public Message receiveMessage(Identifier queueId) {
        QueueConfig queueConfig = fileQMgr.getQueueConfig(queueId);

        logger.log("Pull Message from queueId : " + queueId);
        Message message = fileQMgr.poll(queueId);
        if (message == null)
            return message;

        // Start invisible message timeout handler thread.
        InvisibleTimeoutHandlerThread thread = new InvisibleTimeoutHandlerThread(
                queueId, fileQMgr);

        long visibilityTimeout = Long.parseLong(queueConfig
                .getQueueAttributes()
                .get(QueueAttributeKeys.VISIBILITY_TIMEOUT));
        executorService.schedule(thread, visibilityTimeout,
                TimeUnit.MILLISECONDS);
        logger.log("Next fire time invisibile thread run at : "
                + (System.currentTimeMillis() + visibilityTimeout));
        return message;
    }

    public void deleteMessage(Identifier queueId,
            Identifier messageReceiptHandle) {
        logger.log("Delete message : qid : "+queueId+", msgreceipthandle : "+messageReceiptHandle);
        fileQMgr.deleteMessage(queueId, messageReceiptHandle);
    }

    public List<Identifier> listQueues() {
        return fileQMgr.list();
    }

    /**
     * Invisible timeout handler
     */
    private static class InvisibleTimeoutHandlerThread implements Runnable {
        private Identifier qid;
        private FileQueueManager fileDB;

        public InvisibleTimeoutHandlerThread(Identifier qid,
                FileQueueManager fileDB) {
            this.qid = qid;
            this.fileDB = fileDB;
        }

        public void run() {
            logger.log("Invisible Timeout Handler thread ..."
                    + Thread.currentThread().getId());
            if (Thread.interrupted())
                return;
            // Handle timeout
            this.fileDB.handleMessageTimeout(qid);
        }
    }

    public void deleteAllQueues() {
        // Check if all threads handle interrupts gracefully
        executorService.shutdownNow();
        fileQMgr.deleteAll();
    }

    @Override
    public QueueMetaData getQueueMetaData(Identifier queueIdentifier) {
        return this.fileQMgr.getQueueMetadata(queueIdentifier);
    }
}
