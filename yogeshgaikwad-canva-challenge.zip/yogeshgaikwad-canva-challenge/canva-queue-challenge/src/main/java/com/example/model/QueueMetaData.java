package com.example.model;

/**
 * Queue meta data class describes basic meta data available for an queue.
 * <pre>
 * Note:
 *  The values in the meta data are subject to change after they have been fetched.
 *  The values are populated point in time.
 * </pre> 
 */
public class QueueMetaData {

    /**
     * Includes messages in queue, not exact subject to change
     */
    private long totalUnprocessedMessagesCount = 0;

    /**
     * Includes messages in invisible mode, not exact subject to change
     */
    private long totalInvisibleMessagesCount = 0;

    /**
     * Constructor for Queue meta data
     * @param totalUnprocessedMessagesCount
     *          Denotes total unprocessed messages in queue
     * @param totalInvisibleMessagesCount
     *          Denotes total invisible messages in queue
     */
    public QueueMetaData(long totalUnprocessedMessagesCount,
            long totalInvisibleMessagesCount) {
        super();
        this.totalUnprocessedMessagesCount = totalUnprocessedMessagesCount;
        this.totalInvisibleMessagesCount = totalInvisibleMessagesCount;
    }

    /**
     * @return total unprocessed messages in queue
     */
    public long getTotalUnprocessedMessagesCount() {
        return totalUnprocessedMessagesCount;
    }

    public void setTotalUnprocessedMessagesCount(
            long totalUnprocessedMessagesCount) {
        this.totalUnprocessedMessagesCount = totalUnprocessedMessagesCount;
    }

    /**
     * @return total invisible messages in queue
     */
    public long getTotalInvisibleMessagesCount() {
        return totalInvisibleMessagesCount;
    }

    public void setTotalInvisibleMessagesCount(long totalInvisibleMessagesCount) {
        this.totalInvisibleMessagesCount = totalInvisibleMessagesCount;
    }

}
