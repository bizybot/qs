/**
 * This package contains all the implementations of QueueService interface.
 * Also some specific classed per implementations.
 */
package com.example.service;