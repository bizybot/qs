package com.example.service.impl.file.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Map.Entry;

import com.example.model.Identifier;
import com.example.model.message.Message;
import com.example.model.queue.MessageQueue;
import com.example.model.queue.QueueAttributeKeys;
import com.example.model.queue.QueueConfig;
import com.example.utils.BasicLogger;

public class FileQueue implements MessageQueue {
    private static final long serialVersionUID = 1L;

    private static BasicLogger logger = BasicLogger.getLogger();

    private QueueConfig queueConfig;
    private LinkedList<Message> messages = new LinkedList<Message>();
    private Map<Identifier, MessageEntry> chmInvisibleMessages = new HashMap<Identifier, MessageEntry>();

    public FileQueue(QueueConfig queueConfig) {
        this.queueConfig = queueConfig;
    }

    public QueueConfig getQueueConfig() {
        return queueConfig;
    }

    public void setQueueConfig(QueueConfig queueConfig) {
        this.queueConfig = queueConfig;
    }

    public boolean offerFirst(Message message) {
        boolean retval = messages.offerFirst(message);
        logger.log("After offerFirst : " + messages.size());
        return retval;
    }

    public boolean offer(Message message) {
        boolean retval = messages.offerLast(message);
        logger.log("After offer : " + messages.size());
        return retval;
    }

    public Message poll() {
        Message message = messages.pollFirst();
        if (message == null)
            return null;

        Message messageRetVal = new Message.MessageBuilder()
                .newMessageHandle(message);

        makeMessageInvisible(messageRetVal);
        logger.log("After Poll state : " + messages.size());
        return messageRetVal;
    }

    private void makeMessageInvisible(Message messageRetVal) {
        // Make it invisible
        long visibileTimeout = Long.parseLong(queueConfig.getQueueAttributes()
                .get(QueueAttributeKeys.VISIBILITY_TIMEOUT));

        MessageEntry entry = new MessageEntry(messageRetVal, visibileTimeout);
        chmInvisibleMessages
                .put(messageRetVal.getMessageReceiptHandle(), entry);
        logger.log("Marked message as invisible : " + "MQID : "
                + messageRetVal.getMessageQueueIdentifier() + ", " + "MID : "
                + messageRetVal.getMessageIdentifier() + ", " + "MRH : "
                + messageRetVal.getMessageReceiptHandle());
        logger.log("chmInvisibleMessages : " + chmInvisibleMessages.size());
    }

    public void remove(Identifier messageReceiptHandle) {
        chmInvisibleMessages.remove(messageReceiptHandle);
        logger.log("Remove from chmInvisibleMessages : "
                + chmInvisibleMessages.size());
    }

    public void handleMessageTimeout() {
        logger.log("chmInvisibleMessages : " + chmInvisibleMessages.size());
        Iterator<Entry<Identifier, MessageEntry>> iter = chmInvisibleMessages
                .entrySet().iterator();
        for (; iter.hasNext();) {
            Entry<Identifier, MessageEntry> entry = iter.next();
            if (entry.getValue().hasExpired()) {
                logger.log("Message visibility timeout reached for "
                        + entry.getValue().message.getMessageReceiptHandle());
                // Expired
                iter.remove();
                // Add at first
                offerFirst(entry.getValue().message);
            }
        }
        logger.log("End chmInvisibleMessages : " + chmInvisibleMessages.size());
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime
                * result
                + ((chmInvisibleMessages == null) ? 0 : chmInvisibleMessages
                        .hashCode());
        result = prime * result
                + ((messages == null) ? 0 : messages.hashCode());
        result = prime * result
                + ((queueConfig == null) ? 0 : queueConfig.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        FileQueue other = (FileQueue) obj;
        if (chmInvisibleMessages == null) {
            if (other.chmInvisibleMessages != null)
                return false;
        } else if (!chmInvisibleMessages.equals(other.chmInvisibleMessages))
            return false;
        if (messages == null) {
            if (other.messages != null)
                return false;
        } else if (!messages.equals(other.messages))
            return false;
        if (queueConfig == null) {
            if (other.queueConfig != null)
                return false;
        } else if (!queueConfig.equals(other.queueConfig))
            return false;
        return true;
    }

    private static class MessageEntry implements Serializable {
        private static final long serialVersionUID = 1L;
        private Message message;
        private long expireAt;

        public MessageEntry(Message message, long visibilityTimeout) {
            this.message = message;
            this.expireAt = System.currentTimeMillis() + visibilityTimeout;
            logger.log("Message entry " + message.getMessageReceiptHandle()
                    + " > " + this.expireAt);
        }

        boolean hasExpired() {
            if (System.currentTimeMillis() >= this.expireAt) {
                logger.log("Expired : " + message.getMessageReceiptHandle());
                return true;
            }
            logger.log("Not Expired " + message.getMessageReceiptHandle()
                    + " > " + (System.currentTimeMillis() - expireAt));
            return false;
        }

        @Override
        public int hashCode() {
            final int prime = 31;
            int result = 1;
            result = prime * result
                    + ((message == null) ? 0 : message.hashCode());
            result = prime * result + (int) (expireAt ^ (expireAt >>> 32));
            return result;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj)
                return true;
            if (obj == null)
                return false;
            if (getClass() != obj.getClass())
                return false;
            MessageEntry other = (MessageEntry) obj;
            if (message == null) {
                if (other.message != null)
                    return false;
            } else if (!message.equals(other.message))
                return false;
            if (expireAt != other.expireAt)
                return false;
            return true;
        }
    }

    @Override
    public long getUnprocessedMessageCount() {
        return messages.size();
    }

    @Override
    public long getInvisibleMessageCount() {
        return chmInvisibleMessages.size();
    }
}
