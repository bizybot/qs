package com.example.model.message;

import java.util.HashMap;
import java.util.Map;

public class MessageSendRequest {

    private Message message;
    // not implemented.
    private long delaySeconds = 0;

    private MessageSendRequest() {

    }

    public Message getMessage() {
        return message;
    }

    public void setMessage(Message message) {
        this.message = message;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + (int) (delaySeconds ^ (delaySeconds >>> 32));
        result = prime * result + ((message == null) ? 0 : message.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        MessageSendRequest other = (MessageSendRequest) obj;
        if (delaySeconds != other.delaySeconds)
            return false;
        if (message == null) {
            if (other.message != null)
                return false;
        } else if (!message.equals(other.message))
            return false;
        return true;
    }

    @Override
    public String toString() {
        return "MessageSendRequest [message=" + message + ", delaySeconds="
                + delaySeconds + "]";
    }

    public static class MessageSendRequestBuilder {
        private Message message;
        private Map<String, String> messageAttributes = new HashMap<String, String>();

        public MessageSendRequestBuilder() {

        }

        public MessageSendRequestBuilder withMesage(Message message) {
            this.message = message;
            return this;
        }

        public MessageSendRequestBuilder withAttribute(String key, String value) {
            messageAttributes.put(key, value);
            return this;
        }

        public MessageSendRequest build() {
            MessageSendRequest req = new MessageSendRequest();
            message.setMessageAttributes(messageAttributes);
            req.setMessage(message);
            return req;
        }
    }
}
