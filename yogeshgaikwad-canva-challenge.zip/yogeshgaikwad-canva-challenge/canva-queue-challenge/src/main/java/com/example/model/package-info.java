/**
 * This package contains all interfaces and model objects common across QueueService implementations.
 */
package com.example.model;