package com.example.service.impl.sqs.builders;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import com.amazonaws.services.sqs.model.CreateQueueRequest;
import com.example.model.queue.QueueAttributeKeys;
import com.example.model.queue.QueueConfig;

public class CreateQueueRequestBuilder {
    private CreateQueueRequest request = new CreateQueueRequest();

    public CreateQueueRequestBuilder(QueueConfig queueConfig) {
        request.setQueueName(queueConfig.getQueueName());

        Map<String, String> attributes = new HashMap<String, String>();
        // Attributes convert
        for (Entry<QueueAttributeKeys, String> entry : queueConfig
                .getQueueAttributes().entrySet()) {
            switch (entry.getKey()) {
            case VISIBILITY_TIMEOUT:
                long visibileTimeout = Long.parseLong(entry.getValue());

                attributes.put(entry.getKey().getSqsQueueAttributeKey(), ""
                        + ((long) (visibileTimeout / 1000)));
                break;
            }
        }
        request.setAttributes(attributes);
    }

    public CreateQueueRequest build() {
        return request;
    }
}
