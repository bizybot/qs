package com.example.service.impl.sqs.builders;

public class ReceiveMessageRequestBuilder {

}
