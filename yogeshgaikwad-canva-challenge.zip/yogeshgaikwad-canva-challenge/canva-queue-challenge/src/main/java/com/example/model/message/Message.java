package com.example.model.message;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import com.example.model.Identifier;
import com.example.service.QueueService;

/**
 * Message to be used for messaging between services using {@link QueueService}
 */
public class Message implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * Unique message identifier
     */
    private Identifier messageIdentifier;
    /**
     * Unique message receipt handle.
     * When message is retrieved, it will have this unique handle.
     */
    private Identifier messageReceiptHandle;
    /**
     * Unique message queue identifier.
     */
    private Identifier messageQueueIdentifier;
    /**
     * Message payload.
     */
    private String messagePayload;

    /**
     * Additional message attributes as per user's desire.
     */
    private Map<String, String> messageAttributes;

    /**
     * Constructor
     * @param messageQueueIdentifier Message queue identifier.
     * @param messagePayload message payload
     */
    private Message(Identifier messageQueueIdentifier, String messagePayload) {
        this(new Identifier(UUID.randomUUID().toString()), null,
                messageQueueIdentifier, messagePayload);
    }

    /**
     * Constructor
     * @param messageIdentifier Message identifier
     * @param messageReceiptHandle Message receipt handle
     * @param messageQueueIdentifier Message queue identifier
     * @param messagePayload Message payload
     */
    private Message(Identifier messageIdentifier,
            Identifier messageReceiptHandle, Identifier messageQueueIdentifier,
            String messagePayload) {
        super();
        this.messageIdentifier = messageIdentifier;
        this.messageReceiptHandle = messageReceiptHandle;
        this.messageQueueIdentifier = messageQueueIdentifier;
        this.messagePayload = messagePayload;
    }

    public Identifier getMessageIdentifier() {
        return messageIdentifier;
    }

    public void setMessageIdentifier(Identifier messageIdentifier) {
        this.messageIdentifier = messageIdentifier;
    }

    public Identifier getMessageReceiptHandle() {
        return messageReceiptHandle;
    }

    public void setMessageReceiptHandle(Identifier messageReceiptHandle) {
        this.messageReceiptHandle = messageReceiptHandle;
    }

    public Identifier getMessageQueueIdentifier() {
        return messageQueueIdentifier;
    }

    public void setMessageQueueIdentifier(Identifier messageQueueIdentifier) {
        this.messageQueueIdentifier = messageQueueIdentifier;
    }

    public String getMessagePayload() {
        return messagePayload;
    }

    public void setMessagePayload(String messagePayload) {
        this.messagePayload = messagePayload;
    }

    public Map<String, String> getMessageAttributes() {
        return messageAttributes;
    }

    public void setMessageAttributes(Map<String, String> messageAttributes) {
        this.messageAttributes = messageAttributes;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime
                * result
                + ((messageAttributes == null) ? 0 : messageAttributes
                        .hashCode());
        result = prime
                * result
                + ((messageIdentifier == null) ? 0 : messageIdentifier
                        .hashCode());
        result = prime * result
                + ((messagePayload == null) ? 0 : messagePayload.hashCode());
        result = prime
                * result
                + ((messageQueueIdentifier == null) ? 0
                        : messageQueueIdentifier.hashCode());

        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Message other = (Message) obj;

        if (messageIdentifier == null) {
            if (other.messageIdentifier != null)
                return false;
        } else if (!messageIdentifier.equals(other.messageIdentifier))
            return false;

        if (messageQueueIdentifier == null) {
            if (other.messageQueueIdentifier != null)
                return false;
        } else if (!messageQueueIdentifier.equals(other.messageQueueIdentifier))
            return false;

        if (messageAttributes == null) {
            if (other.messageAttributes != null)
                return false;
        } else if (!messageAttributes.equals(other.messageAttributes))
            return false;

        if (messagePayload == null) {
            if (other.messagePayload != null)
                return false;
        } else if (!messagePayload.equals(other.messagePayload))
            return false;

        return true;
    }

    @Override
    public String toString() {
        return "Message [messageIdentifier=" + messageIdentifier
                + ", messageReceiptHandle=" + messageReceiptHandle
                + ", messageQueueIdentifier=" + messageQueueIdentifier
                + ", messagePayload=" + messagePayload + ", messageAttributes="
                + messageAttributes + "]";
    }

    public static class MessageBuilder {

        private Identifier queueId;
        private String msgPayload;

        public MessageBuilder() {
        }

        public MessageBuilder withQueueId(Identifier qid) {
            queueId = qid;
            return this;
        }

        public MessageBuilder withMessagePayload(String msgPayload) {
            this.msgPayload = msgPayload;
            return this;
        }

        public Message build() {
            return new Message(queueId, msgPayload);
        }

        public Message newMessageHandle(Message message) {
            Message messageRet = new Message(message.getMessageIdentifier(),
                    new Identifier(UUID.randomUUID().toString()),
                    message.getMessageQueueIdentifier(),
                    message.getMessagePayload());
            if (message.getMessageAttributes() != null)
                messageRet.setMessageAttributes(new HashMap<String, String>(
                        message.getMessageAttributes()));
            return messageRet;
        }
    }
}
