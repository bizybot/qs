package com.example.model.queue;

import java.io.Serializable;

import com.example.model.Identifier;
import com.example.model.message.Message;
import com.example.model.queue.QueueConfig.QueueConfigBuilder;

/**
 * Internal class for managing file backed, in memory queues.
 * Interface for Message Queue. Provides basic operations for adding, poll and
 * remove of messages in the Queue.
 */
public interface MessageQueue extends Serializable {

    /**
     * Set Message Queue configuration.
     * @param queueConfig {@link QueueConfig}
     */
    public void setQueueConfig(QueueConfig queueConfig);

    /**
     * Get Queue configuration.
     * @return {@link QueueConfig} if queue present, else returns <code>null</code>
     */
    public QueueConfig getQueueConfig();

    /**
     * Offer message to Queue at last.
     * @param message {@link Message}
     * @return <code>true</code> if added to queue else <code>false</code>
     */
    public boolean offer(Message message);

    /**
     * Offer message to Queue at Front.
     * @param message {@link Message}
     * @return <code>true</code> if added to queue else <code>false</code>
     */
    public boolean offerFirst(Message message);

    /**
     * Poll message from the Queue.
     * <pre>
     *  1. When polled from the Queue, message is not removed it is marked invisible for configured
     *     visibility timeout {@link QueueConfigBuilder#addAttribute(QueueAttributeKeys, String)}.
     *  2. Remember that once the message is removed from the Queue, 
     *     it has to be deleted using message handle.
     *     {@link #remove(Identifier)}
     *  3. If not removed within visibility timeout then the message is re-added to the queue in front. 
     * </pre>
     * @return {@link Message} instance if message was polled, else will return <code>null</code> 
     */
    public Message poll();

    /**
     * Remove from the message if marked invisible, if message handle is not latest then it does nothing.
     * @param messageReceiptHandle
     */
    public void remove(Identifier messageReceiptHandle);

    /**
     * Interface method for handling message timeout.
     * Not for consumption.
     */
    public void handleMessageTimeout();

    /**
     * Returns current unprocessed message count, not exact as subject to change
     * @return count of unprocessed messages in queue.
     */
    public long getUnprocessedMessageCount();

    /**
     * Returns current invisible message count, not exact as subject to change
     * @return count of invisible messages in queue.
     */
    public long getInvisibleMessageCount();
}
