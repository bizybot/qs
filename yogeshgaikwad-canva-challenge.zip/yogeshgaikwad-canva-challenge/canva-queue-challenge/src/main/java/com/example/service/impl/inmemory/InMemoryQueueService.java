package com.example.service.impl.inmemory;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import com.example.model.Identifier;
import com.example.model.QueueMetaData;
import com.example.model.message.Message;
import com.example.model.message.MessageSendRequest;
import com.example.model.queue.QueueAttributeKeys;
import com.example.model.queue.QueueConfig;
import com.example.service.QueueService;
import com.example.service.impl.inmemory.model.InMemoryQueue;
import com.example.utils.BasicLogger;

/**
 * In memory queue service implementation.
 */
public class InMemoryQueueService implements QueueService {
    private static BasicLogger logger = BasicLogger.getLogger();

    /**
     * Concurrent HashMap to store created Queues and the messages.
     * This map itself serves as DB for existing Queues in the system.
     */
    private ConcurrentHashMap<Identifier, InMemoryQueue> queueMessages = new ConcurrentHashMap<Identifier, InMemoryQueue>();

    /**
     * Single Thread Executor.
     */
    private ScheduledExecutorService executorService = Executors
            .newScheduledThreadPool(100);

    public Identifier createQueue(QueueConfig queueConfig) {
        logger.log("Create Queue " + queueConfig);
        Identifier id = new Identifier(UUID.randomUUID().toString());
        InMemoryQueue inMemQueue = new InMemoryQueue(queueConfig);
        queueMessages.put(id, inMemQueue);
        return id;
    }

    public void deleteQueue(Identifier queueId) {
        logger.log("Delete Queue with Id : " + queueId);
        queueMessages.remove(queueId);
    }

    public void sendMessage(MessageSendRequest messageSendRequest) {
        logger.log("Send Message : " + messageSendRequest);

        queueMessages.get(
                messageSendRequest.getMessage().getMessageQueueIdentifier())
                .offer(messageSendRequest.getMessage());
    }

    public Message receiveMessage(Identifier queueId) {
        logger.log("Pull Message from queueId : " + queueId);
        Message message = queueMessages.get(queueId).poll();
        if (message == null)
            return message;

        InMemoryQueue inMemoryQueue = queueMessages.get(message
                .getMessageQueueIdentifier());
        InvisibleTimeoutHandlerThread invisibleTimeoutThread = new InvisibleTimeoutHandlerThread(
                inMemoryQueue);
        long visibileTimeout = Long.parseLong(inMemoryQueue.getQueueConfig()
                .getQueueAttributes()
                .get(QueueAttributeKeys.VISIBILITY_TIMEOUT));
        executorService.schedule(invisibleTimeoutThread, visibileTimeout,
                TimeUnit.MILLISECONDS);
        return message;
    }

    public void deleteMessage(Identifier queueId,
            Identifier messageReceiptHandle) {
        queueMessages.get(queueId).remove(messageReceiptHandle);
    }

    public List<Identifier> listQueues() {
        return new ArrayList<Identifier>(queueMessages.keySet());
    }

    private static class InvisibleTimeoutHandlerThread implements Runnable {
        private InMemoryQueue inMemQueue;

        public InvisibleTimeoutHandlerThread(InMemoryQueue inMemQueue) {
            this.inMemQueue = inMemQueue;
        }

        public void run() {
            logger.log("Invisible Timeout Handler thread ...");
            if (Thread.interrupted())
                return;
            this.inMemQueue.handleMessageTimeout();
        }
    }

    public void deleteAllQueues() {
        // Check if all threads handle interrupts gracefully
        executorService.shutdownNow();
        queueMessages.clear();
    }

    @Override
    public QueueMetaData getQueueMetaData(Identifier queueIdentifier) {
        InMemoryQueue q = this.queueMessages.get(queueIdentifier);
        if (q == null)
            return null;
        return new QueueMetaData(q.getUnprocessedMessageCount(),
                q.getInvisibleMessageCount());
    }
}
