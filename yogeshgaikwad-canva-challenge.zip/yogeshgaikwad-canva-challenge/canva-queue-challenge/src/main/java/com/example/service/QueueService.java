package com.example.service;

import java.util.List;

import com.example.model.Identifier;
import com.example.model.QueueMetaData;
import com.example.model.message.Message;
import com.example.model.message.MessageSendRequest;
import com.example.model.queue.QueueConfig;
import com.example.service.impl.inmemory.InMemoryQueueService;

/**
 * Interface class for various backing implementations Queue Service.
 * <pre>
 *  For example, {@link InMemoryQueueService} is an implementation of QueueService which provides
 *  basic functionality where the Queue is in memory. Once you exit JVM, it would not be available.
 *  Also it is only available to be consumed within JVM.
 * 
 *  Example Usage :-
 *
 * {@code
 *  QueueService qs = new InMemoryQueueService();
 *  //Create Queue
 *  QueueConfig qConfig = new QueueConfig.QueueConfigBuilder()
                        .withQueueName("Q1")
                        .addAttribute(QueueAttributeKeys.VISIBILITY_TIMEOUT,
                                "1000").build();
 *  Identifier qid = qs.createQueue(qConfig);
 *
 *  // Send Message
 *  Message msg = new Message.MessageBuilder().withQueueId(qid)
                            .withMessagePayload("Hello World !").build();
 *  MessageSendRequest msr = new MessageSendRequestBuilder().withMesage(msg).build();
 *  qs.sendMessage(msr);
 *
 *  // Receive Message
 *  Message messageRetVal = qs.receiveMessage(qid);
 *
 *  // Delete message using message receipt handle
 *  qs.deleteMessage(qid, messageRetVal.getMessageReceiptHandle());
 * }
 */
public interface QueueService {

    /**
     * Creates a new Queue using provided QueueConfig.
     * 
     * @param queueConfig
     *            Queue Configuration details {@link QueueConfig}
     * @return {@link Identifier} Queue Identifier
     */
    public Identifier createQueue(QueueConfig queueConfig);

    /**
     * Delete Queue if present.
     * 
     * @param queueId
     *            {@link Identifier} identifier for Queue to be deleted.
     */
    public void deleteQueue(Identifier queueId);

    /**
     * Delete all queues.
     */
    public void deleteAllQueues();

    /**
     * Lists all the queues created.
     * 
     * @return List of Queue {@link Identifier}'s.
     */
    public List<Identifier> listQueues();

    /**
     * Send message to the desired Queue.
     * 
     * @param messageSendRequest
     *            {@link MessageSendRequest} request containing message to be queued.
     */
    public void sendMessage(MessageSendRequest messageSendRequest);

    /**
     * Poll message from the Queue. <strong>Note: </strong> Remember to delete
     * the message from the Queue
     * {@link QueueService#deleteMessage(Identifier, Identifier)}
     * 
     * @return Instance of {@link Message} from Queue.
     */
    public Message receiveMessage(Identifier queueId);

    /**
     * Delete message from given queue and for message handle.
     * If the message handle is not recent one, then it does not do anything.
     * @param queueIdentifier
     * @param messageReceiptHandle
     */
    public void deleteMessage(Identifier queueIdentifier,
            Identifier messageReceiptHandle);

    /**
     * Returns Queue meta data, metrics.
     * @param queueIdentifier {@link Identifier} of Queue.
     * @return {@link QueueMetaData}
     */
    public QueueMetaData getQueueMetaData(Identifier queueIdentifier);
}
