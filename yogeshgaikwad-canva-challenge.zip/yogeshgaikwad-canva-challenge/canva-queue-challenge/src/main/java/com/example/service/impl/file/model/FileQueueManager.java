package com.example.service.impl.file.model;

import java.io.File;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.example.model.Identifier;
import com.example.model.QueueMetaData;
import com.example.model.message.Message;
import com.example.model.queue.QueueConfig;
import com.example.utils.BasicLogger;

/**
 * This class manages file operations.
 * This uses FileLock for managing resource contention between JVMs.
 */
public class FileQueueManager {
    private static BasicLogger logger = BasicLogger.getLogger();

    private File dbDirectory;
    private File dbFile;
    private File dbLockFile;

    private FileChannel fileChannel;
    private FileLock fileLock;

    /*
     * Structure for operations
     * 
     *  Lock file
     *  
     *  Load DB
     *  
     *  Operate
     *  
     *  Commit
     *  
     *  Unlock
     */
    
    /**
     * Create File Queue Manager, creates DB for persisting queue information.
     * @param dbDirectory Directory path where DB file would be managed.
     * @param dbFileName DB file name.
     */
    public FileQueueManager(String dbDirectory, String dbFileName) {
        this.dbDirectory = new File(dbDirectory);
        if (!this.dbDirectory.exists()) {
            throw new IllegalArgumentException(
                    "Provided directory for DB does not exist");
        }

        this.dbFile = new File(dbDirectory + File.separator + dbFileName);
        if (!this.dbFile.exists()) {
            boolean created = false;
            try {
                created = this.dbFile.createNewFile();
                if (created) {
                    logger.log("Created DB file");
                } else {
                    logger.log("Already exists");
                }
            } catch (IOException e) {
                logger.log("Exception occurred while creating DB file.", e);
            }

        }
        this.dbLockFile = new File(dbDirectory + File.separator + dbFileName
                + ".lock");
        if (!this.dbLockFile.exists()) {
            try {
                this.dbLockFile.createNewFile();
            } catch (IOException e) {
                logger.log("Exception occurred while creating DB Lock file.", e);
            }
        }

        try {
            this.fileChannel = FileChannel.open(this.dbLockFile.toPath(),
                    StandardOpenOption.APPEND);
        } catch (IOException e) {
            logger.log(
                    "Exception occurred while opening channel for lock file.",
                    e);
        }

    }

    public synchronized void put(Identifier identifier, FileQueue messageQueue) {
        logger.log("Put : " + identifier + ", " + messageQueue);

        FileDB db = null;
        boolean persist = false;
        try {
            // Lock file
            lock();

            // Load DB
            db = getDB();
            // Operate
            HashMap<Identifier, FileQueue> htMap = db.hashMap();
            htMap.put(identifier, messageQueue);
            persist = true;

        } catch (Throwable t) {
            t.printStackTrace();
            // Exception roll back
            if (db != null)
                db.rollback();
            persist = false;
        } finally {
            // Commit if success
            if (db != null && persist)
                db.commit();
            if (db != null)
                db.close();
            unlock();
        }
        logger.log("Put : Done");
    }

    public synchronized void remove(Identifier identifier) {
        FileDB db = null;
        boolean persist = false;
        try {
            // Lock file
            lock();

            // Load DB
            db = getDB();
            // operate
            HashMap<Identifier, FileQueue> htMap = db.hashMap();
            htMap.remove(identifier);
            persist = true;

        } catch (Throwable t) {
            t.printStackTrace();
            if (db != null)
                db.rollback();
            persist = false;
        } finally {
            // Commit if success
            if (db != null && persist)
                db.commit();
            if (db != null)
                db.close();
            // Always unlock
            unlock();
        }

    }

    public synchronized List<Identifier> list() {
        logger.log("List queues");
        FileDB db = null;
        boolean persist = false;
        try {
            // Lock file
            lock();

            // Load DB
            db = getDB();
            // Operate
            HashMap<Identifier, FileQueue> htMap = db.hashMap();
            List<Identifier> ids = new ArrayList<Identifier>(htMap.keySet());
            persist = false; //readonly
            return ids;
        } catch (Throwable t) {
            t.printStackTrace();
            persist = false;
            return null;
        } finally {
            if (db != null && persist)
                db.commit();
            if (db != null)
                db.close();
            // Unlock
            unlock();
        }

    }

    public synchronized QueueConfig getQueueConfig(Identifier id) {
        logger.log("Get QueueConfig");
        FileDB db = null;
        boolean persist = false;
        try {
            lock();

            db = getDB();
            HashMap<Identifier, FileQueue> htMap = db.hashMap();
            if (htMap.get(id) == null) {
                return null;
            }

            QueueConfig qConfig = htMap.get(id).getQueueConfig();
            return qConfig;
        } catch (Throwable t) {
            t.printStackTrace();
            persist = false;
            return null;
        } finally {
            if (db != null && persist)
                db.commit();
            if (db != null)
                db.close();
            unlock();
        }

    }

    public synchronized QueueMetaData getQueueMetadata(Identifier id) {
        logger.log("Get QueueMetaData");
        FileDB db = null;
        boolean persist = false;
        try {
            lock();

            db = getDB();
            HashMap<Identifier, FileQueue> htMap = db.hashMap();
            if (htMap.get(id) == null)
                return null;
            QueueMetaData qConfig = new QueueMetaData(htMap.get(id)
                    .getUnprocessedMessageCount(), htMap.get(id)
                    .getInvisibleMessageCount());
            return qConfig;
        } catch (Throwable t) {
            t.printStackTrace();
            persist = false;
            return null;
        } finally {
            if (db != null && persist)
                db.commit();
            if (db != null)
                db.close();
            unlock();
        }

    }

    public synchronized void offer(Message message) {
        logger.log("Offer : " + message);
        FileDB db = null;
        boolean persist = false;
        try {
            lock();

            db = getDB();
            HashMap<Identifier, FileQueue> htMap = db.hashMap();
            FileQueue fq = htMap.remove(message.getMessageQueueIdentifier());
            if (fq == null)
                return;

            fq.offer(message);
            htMap.put(message.getMessageQueueIdentifier(), fq);
            persist = true;

        } catch (Throwable t) {
            logger.log("Error occurred while offering message to queue : "
                    + message.getMessageQueueIdentifier(), t);
            if (db != null)
                db.rollback();
            persist = false;
        } finally {
            if (db != null && persist)
                db.commit();
            if (db != null)
                db.close();
            unlock();
        }
    }

    public synchronized Message poll(Identifier identifier) {
        logger.log("Poll - " + identifier);
        FileDB db = null;
        boolean persist = false;
        Message message = null;
        try {
            lock();

            db = getDB();
            HashMap<Identifier, FileQueue> htMap = db.hashMap();
            FileQueue fq = htMap.get(identifier);
            if (fq == null)
                return null;
            message = fq.poll();
            if (message == null)
                return message;
            htMap.put(message.getMessageQueueIdentifier(), fq);
            persist = true;

        } catch (Throwable t) {
            logger.log("Error occurred while polling - " + identifier, t);
            if (db != null)
                db.rollback();
            persist = false;
        } finally {
            if (db != null && persist)
                db.commit();
            if (db != null)
                db.close();
            unlock();
        }
        return message;
    }

    public synchronized void deleteMessage(Identifier queueId,
            Identifier messageReceiptHandle) {
        logger.log("DeleteMessage - " + queueId + ", " + messageReceiptHandle);
        FileDB db = null;
        boolean persist = false;
        try {
            lock();

            db = getDB();
            HashMap<Identifier, FileQueue> htMap = db.hashMap();
            FileQueue fq = htMap.get(queueId);
            if (fq == null)
                return;
            fq.remove(messageReceiptHandle);
            htMap.put(queueId, fq);
            persist = true;

        } catch (Throwable t) {
            logger.log("Error occurred while deleting - " + queueId + ", "
                    + messageReceiptHandle, t);
            if (db != null)
                db.rollback();
            persist = false;
        } finally {
            if (db != null && persist)
                db.commit();
            if (db != null)
                db.close();
            unlock();
        }
    }

    public synchronized void handleMessageTimeout(Identifier queueId) {
        logger.log("HandleMessageTimeout");
        FileDB db = null;
        boolean persist = false;
        try {
            lock();

            db = getDB();
            HashMap<Identifier, FileQueue> htMap = db.hashMap();
            FileQueue fq = htMap.get(queueId);
            if (fq == null)
                return;
            fq.handleMessageTimeout();
            htMap.put(queueId, fq);
            persist = true;

        } catch (Throwable t) {
            logger.log(
                    "Error while deleting handle message timeout for queue : "
                            + queueId, t);
            if (db != null)
                db.rollback();
            persist = false;
        } finally {
            if (db != null && persist)
                db.commit();
            if (db != null)
                db.close();
            unlock();
        }
    }

    public synchronized void deleteAll() {
        FileDB db = null;
        boolean persist = false;
        try {
            lock();

            db = getDB();
            HashMap<Identifier, FileQueue> htMap = db.hashMap();
            if (htMap.isEmpty()) {
                logger.log("No queues exists returning");
                return;
            }
            htMap.clear();
            persist = true;

        } catch (Throwable t) {
            logger.log("Error while deleting all queues", t);
            if (db != null)
                db.rollback();
            persist = false;
        } finally {
            if (db != null && persist)
                db.commit();
            if (db != null)
                db.close();
            unlock();
        }
    }

    // Private
    private void lock() {
        int tryCount = 0;
        for (; tryCount < 15; tryCount++) {
            try {
                FileLock fileLockGet = fileChannel.tryLock();
                while (fileLockGet == null) {
                    logger.log(Thread.currentThread().getId()
                            + " Waiting for Lock");
                    Thread.sleep(50);
                    fileLockGet = fileChannel.tryLock();
                }
                // Got lock
                fileLock = fileLockGet;
                logger.log("Received file lock.");
                break;
            } catch (IOException ioe) {
                logger.log("Error while trying file lock", ioe);
            } catch (InterruptedException e) {
                logger.log("Error while trying file lock", e);
            }
        }
    }

    private void unlock() {
        try {
            if (fileLock != null) {
                logger.log("Released file lock.");
                fileLock.release();
            }
            fileLock = null;
        } catch (IOException e) {
            logger.log("Error while releasing file lock", e);
        }
    }

    private FileDB getDB() {
        logger.log("GetDB");
        return new FileDB(dbFile.getAbsolutePath());
    }

}
