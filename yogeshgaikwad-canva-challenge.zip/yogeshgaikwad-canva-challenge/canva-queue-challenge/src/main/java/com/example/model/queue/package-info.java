/**
 * This package contains of all classes related to MessageQueue interface
 */
package com.example.model.queue;