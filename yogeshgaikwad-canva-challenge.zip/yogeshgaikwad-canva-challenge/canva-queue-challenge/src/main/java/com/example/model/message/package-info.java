/**
 * This package contains of all model objects related to Message.
 */
package com.example.model.message;