package com.example.exceptions;

public class InvalidArgumentException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public InvalidArgumentException(String paramName, String validValues) {
        super("Invalid argument : " + paramName + " : valid values : "
                + validValues);
    }
}
