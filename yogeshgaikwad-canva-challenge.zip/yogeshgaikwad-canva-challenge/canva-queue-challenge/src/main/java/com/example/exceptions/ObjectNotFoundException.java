package com.example.exceptions;

/**
 * This exception class is used to throw exceptions when object is not found.
 */
public class ObjectNotFoundException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public ObjectNotFoundException(String message) {
        super(message);
    }
}
