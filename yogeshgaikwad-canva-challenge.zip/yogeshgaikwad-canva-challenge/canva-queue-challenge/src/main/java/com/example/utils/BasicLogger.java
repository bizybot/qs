package com.example.utils;

import java.util.logging.Logger;

/**
 * Logger utility - Basic
 */
public class BasicLogger {
    private static final Logger logger = Logger.getLogger("QS");

    private static final BasicLogger instance = new BasicLogger();

    private BasicLogger() {

    }

    public static BasicLogger getLogger() {
        return instance;
    }

    public void log(String message) {
        log(message, null);
    }

    public void log(String message, Throwable t) {
        logger.info(message);
        if (t != null)
            t.printStackTrace();
    }
}
