package com.example.file;

import java.io.File;

import org.junit.After;
import org.junit.Before;

import com.example.BaseQueueServiceTest;
import com.example.service.impl.file.FileQueueService;
import com.example.service.impl.file.model.FileQueueManager;

public class FileQueueServiceTest extends BaseQueueServiceTest {

    int counter = 0;

    @Before
    public void before() {
        String directory = properties.getProperty("qs.file.directory");
        FileQueueManager fileDB = new FileQueueManager(directory,
                "fsq.db" + counter);
        queueService = new FileQueueService(fileDB);
    }

    @After
    public void after() {
        queueService.deleteAllQueues();
        String directory = properties.getProperty("qs.file.directory");
        File file = new File(directory + File.separator + "fsq.db" + counter);
        if (file.exists()) {
            file.delete();
        }
        File file1 = new File(directory + File.separator + "fsq.db" + counter + ".wal.0");
        if (file1.exists()) {
            file1.delete();
        }
        File file2 = new File(directory + File.separator + "fsq.db" + counter + ".lock");
        if (file2.exists()) {
            file2.delete();
        }
        queueService = null;
        counter++;
    }
}
