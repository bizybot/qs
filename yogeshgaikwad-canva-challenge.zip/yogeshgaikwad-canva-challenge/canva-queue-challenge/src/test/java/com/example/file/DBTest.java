package com.example.file;

import java.io.File;
import java.io.IOException;
import java.util.Properties;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.example.model.Identifier;
import com.example.model.queue.QueueAttributeKeys;
import com.example.model.queue.QueueConfig.QueueConfigBuilder;
import com.example.service.impl.file.model.FileDB;
import com.example.service.impl.file.model.FileQueue;
import com.example.sqs.SQSQueueServiceTest;

/**
 * File based DB test
 */
public class DBTest {
    private static Properties properties = new Properties();
    {
        try {
            properties.load(SQSQueueServiceTest.class
                    .getResourceAsStream("/queue-service-test.properties"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    private FileDB db = null;

    @Before
    public void setUp() throws Exception {
        String directory = properties.getProperty("qs.file.directory");
        File file = new File(directory+File.separator+"hm.db");
        if (file.exists())
            file.delete();

        db = new FileDB(directory+File.separator+"hm.db");
    }

    @After
    public void tearDown() throws Exception {
        String directory = properties.getProperty("qs.file.directory");
        File file = new File(directory+File.separator+"hm.db");
        if (file.exists())
            file.delete();
    }

    @Test
    public void testPutKey() {
        Identifier id = new Identifier("1");
        FileQueue fq = new FileQueue(new QueueConfigBuilder()
                .withQueueName("q")
                .addAttribute(QueueAttributeKeys.VISIBILITY_TIMEOUT, "100")
                .build());
        db.hashMap().put(id, fq);
        db.commit();
        db.close();

        Assert.assertTrue(db.hashMap().containsKey(id));
        Assert.assertTrue(db.hashMap().containsValue(fq));
    }

    @Test
    public void testPutKeysandRemove() {
        Identifier id = new Identifier("1");
        FileQueue fq = new FileQueue(new QueueConfigBuilder()
                .withQueueName("q1")
                .addAttribute(QueueAttributeKeys.VISIBILITY_TIMEOUT, "100")
                .build());
        db.hashMap().put(id, fq);
        Identifier id1 = new Identifier("2");
        FileQueue fq1 = new FileQueue(new QueueConfigBuilder()
                .withQueueName("q2")
                .addAttribute(QueueAttributeKeys.VISIBILITY_TIMEOUT, "100")
                .build());
        db.hashMap().put(id1, fq1);
        db.commit();
        db.close();

        Assert.assertTrue(db.hashMap().containsKey(id));
        Assert.assertTrue(db.hashMap().containsValue(fq));
        Assert.assertTrue(db.hashMap().containsKey(id1));
        Assert.assertTrue(db.hashMap().containsValue(fq1));

        db.hashMap().remove(id);
        db.commit();
        db.close();

        Assert.assertFalse(db.hashMap().containsKey(id));

    }

    @Test
    public void testPutKeysandRemoveRollback() {
        Identifier id = new Identifier("1");
        FileQueue fq = new FileQueue(new QueueConfigBuilder()
                .withQueueName("q1")
                .addAttribute(QueueAttributeKeys.VISIBILITY_TIMEOUT, "100")
                .build());
        db.hashMap().put(id, fq);
        Identifier id1 = new Identifier("2");
        FileQueue fq1 = new FileQueue(new QueueConfigBuilder()
                .withQueueName("q2")
                .addAttribute(QueueAttributeKeys.VISIBILITY_TIMEOUT, "100")
                .build());
        db.hashMap().put(id1, fq1);
        db.commit();
        db.close();

        Assert.assertTrue(db.hashMap().containsKey(id));
        Assert.assertTrue(db.hashMap().containsValue(fq));
        Assert.assertTrue(db.hashMap().containsKey(id1));
        Assert.assertTrue(db.hashMap().containsValue(fq1));

        db.hashMap().remove(id);
        db.rollback();
        db.close();

        Assert.assertTrue(db.hashMap().containsKey(id));
        Assert.assertTrue(db.hashMap().containsValue(fq));
        Assert.assertTrue(db.hashMap().containsKey(id1));
        Assert.assertTrue(db.hashMap().containsValue(fq1));

    }

}
