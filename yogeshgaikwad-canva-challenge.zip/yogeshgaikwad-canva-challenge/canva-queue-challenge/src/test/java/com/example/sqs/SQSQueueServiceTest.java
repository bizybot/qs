package com.example.sqs;

import java.io.IOException;
import java.util.List;
import java.util.Properties;

import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.amazonaws.AmazonClientException;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.sqs.AmazonSQSClient;
import com.example.model.Identifier;
import com.example.model.message.Message;
import com.example.model.message.MessageSendRequest;
import com.example.model.queue.QueueAttributeKeys;
import com.example.model.queue.QueueConfig.QueueConfigBuilder;
import com.example.service.impl.sqs.SqsQueueService;
import com.example.utils.BasicLogger;

public class SQSQueueServiceTest {
    protected static BasicLogger logger = BasicLogger.getLogger();

    private static AmazonSQSClient client = null;
    private static Properties properties = new Properties();
    {
        try {
            properties.load(SQSQueueServiceTest.class
                    .getResourceAsStream("/queue-service-test.properties"));
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    private SqsQueueService sqsQueueService = null;

    @BeforeClass
    public static void setUp() throws Exception {

        AWSCredentials credentials = null;
        try {
            credentials = new AWSCredentials() {

                @Override
                public String getAWSSecretKey() {
                    return properties
                            .getProperty("qs.sqs.aws_secret_access_key");
                }

                @Override
                public String getAWSAccessKeyId() {
                    return properties.getProperty("qs.sqs.aws_access_key_id");
                }
            };
        } catch (Exception e) {
            throw new AmazonClientException(
                    "Cannot load the credentials. "
                            + "Please make sure that your credentials are correct and in valid format.",
                    e);
        }

        client = new AmazonSQSClient(credentials);
        Region usWest2 = Region.getRegion(Regions.US_WEST_2);
        client.setRegion(usWest2);
    }

    @Before
    public void before() {
        if (sqsQueueService == null)
            sqsQueueService = new SqsQueueService(client);
    }

    @Test
    public void testCreateQueueListQueueDeleteQueue() {
        List<Identifier> identifiers = sqsQueueService.listQueues();
        int initialSize = identifiers.size();
        logger.log("Initial Queue Size : "+initialSize);

        Identifier id = sqsQueueService.createQueue(new QueueConfigBuilder()
                .withQueueName("aws-sqs-q1")
                .addAttribute(QueueAttributeKeys.VISIBILITY_TIMEOUT, "60000")
                .build());
        Assert.assertNotNull(id);
        logger.log("Created SQS Queue with URL : " + id);

        try {
            logger.log("Sleep 1 minute so that queue gets created and is available : " + id);
            Thread.sleep(60000);
        } catch (InterruptedException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }

        identifiers = sqsQueueService.listQueues();
        Assert.assertTrue(identifiers.contains(id));
        logger.log("Verified list of Queues contains id : " + id);

        String msgPayLoad = "Test Message";
        Message messageSnd = new Message.MessageBuilder().withQueueId(id)
                .withMessagePayload(msgPayLoad).build();
        sqsQueueService
                .sendMessage(new MessageSendRequest.MessageSendRequestBuilder()
                        .withMesage(messageSnd).withAttribute("k1", "v1")
                        .build());

        logger.log("Send message : " + messageSnd);

        Message message = sqsQueueService.receiveMessage(id);
        Assert.assertNotNull(message);
        Assert.assertEquals(msgPayLoad, message.getMessagePayload());
        Assert.assertEquals(messageSnd.getMessageAttributes(),
                message.getMessageAttributes());

        logger.log("Received message : " + message);

        // Delete Queue
        sqsQueueService.deleteQueue(id);

        logger.log("Deleted Queue now sleep for 1 minute as it takes time to reflect : " + message);
        // Sleep so that delete happens
        try {
            Thread.sleep(70000);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        identifiers = sqsQueueService.listQueues();
        Assert.assertFalse(identifiers.contains(id));
    }
}
