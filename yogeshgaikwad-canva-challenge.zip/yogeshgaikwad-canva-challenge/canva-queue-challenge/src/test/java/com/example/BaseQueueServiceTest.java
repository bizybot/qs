package com.example;

import java.io.IOException;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.example.model.Identifier;
import com.example.model.QueueMetaData;
import com.example.model.message.Message;
import com.example.model.message.MessageSendRequest;
import com.example.model.queue.QueueAttributeKeys;
import com.example.model.queue.QueueConfig;
import com.example.service.QueueService;
import com.example.sqs.SQSQueueServiceTest;
import com.example.utils.BasicLogger;

public abstract class BaseQueueServiceTest {
    protected static BasicLogger logger = BasicLogger.getLogger();

    protected static Properties properties = new Properties();
    {
        try {
            properties.load(SQSQueueServiceTest.class
                    .getResourceAsStream("/queue-service-test.properties"));
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    protected QueueService queueService;

    @Before
    public abstract void before();

    @After
    public abstract void after();

    @Test
    public void testCreateDeleteListQueue() {
        logger.log("############### testCreateDeleteListQueue ####################");
        QueueConfig queueConfig = new QueueConfig.QueueConfigBuilder()
                .withQueueName("Test-Q")
                .addAttribute(QueueAttributeKeys.VISIBILITY_TIMEOUT, "100")
                .build();
        // Create Queue
        Identifier qid = queueService.createQueue(queueConfig);
        Assert.assertNotNull(qid);
        Assert.assertEquals(1, queueService.listQueues().size());
        // Delete Queue
        queueService.deleteQueue(qid);
        Assert.assertEquals(0, queueService.listQueues().size());
    }

    @Test
    public void testPushMessageOnQueue() {
        logger.log("############### testPushMessageOnQueue ####################");
        QueueConfig queueConfig = new QueueConfig.QueueConfigBuilder()
                .withQueueName("Test-Q")
                .addAttribute(QueueAttributeKeys.VISIBILITY_TIMEOUT, "100")
                .build();
        // Create Queue
        Identifier qid = queueService.createQueue(queueConfig);
        Assert.assertNotNull(qid);

        // Send Message
        String msgPayLoad = "Test Message";
        Message messageSnd = new Message.MessageBuilder().withQueueId(qid)
                .withMessagePayload(msgPayLoad).build();
        queueService
                .sendMessage(new MessageSendRequest.MessageSendRequestBuilder()
                        .withMesage(messageSnd).withAttribute("k1", "v1")
                        .build());

        // Queue metadata verification
        QueueMetaData qmd = queueService.getQueueMetaData(qid);
        Assert.assertEquals(1, qmd.getTotalUnprocessedMessagesCount());
        Assert.assertEquals(0, qmd.getTotalInvisibleMessagesCount());

        // Receive message
        Message message = queueService.receiveMessage(qid);
        Assert.assertNotNull(message);
        Assert.assertEquals(msgPayLoad, message.getMessagePayload());
        Assert.assertEquals(messageSnd.getMessageAttributes(),
                message.getMessageAttributes());

        // Queue metadata verification
        qmd = queueService.getQueueMetaData(qid);
        Assert.assertEquals(0, qmd.getTotalUnprocessedMessagesCount());
        Assert.assertEquals(1, qmd.getTotalInvisibleMessagesCount());

    }

    @Test
    public void testPushMessagesOnQueueRemoveUsingHandle() {
        logger.log("############### testPushMessageOnQueueRemoveUsingHandle ####################");
        QueueConfig queueConfig = new QueueConfig.QueueConfigBuilder()
                .withQueueName("Test-Q")
                .addAttribute(QueueAttributeKeys.VISIBILITY_TIMEOUT, "1000")
                .build();
        // Create Queue
        Identifier qid = queueService.createQueue(queueConfig);
        Assert.assertNotNull(qid);

        // Send message
        String msgPayLoad = "Test Message";
        Message messageSnd = new Message.MessageBuilder().withQueueId(qid)
                .withMessagePayload(msgPayLoad).build();
        queueService
                .sendMessage(new MessageSendRequest.MessageSendRequestBuilder()
                        .withMesage(messageSnd).withAttribute("k1", "v1")
                        .build());
        QueueMetaData qmd = queueService.getQueueMetaData(qid);
        Assert.assertEquals(1, qmd.getTotalUnprocessedMessagesCount());
        Assert.assertEquals(0, qmd.getTotalInvisibleMessagesCount());

        // Receive message
        Message message = queueService.receiveMessage(qid);
        Assert.assertNotNull(message);
        Assert.assertEquals(msgPayLoad, message.getMessagePayload());
        Assert.assertNotNull(message.getMessageReceiptHandle());

        qmd = queueService.getQueueMetaData(qid);
        Assert.assertEquals(0, qmd.getTotalUnprocessedMessagesCount());
        Assert.assertEquals(1, qmd.getTotalInvisibleMessagesCount());

        // Try polling again since it will be invisible should return null.
        Message message1 = queueService.receiveMessage(qid);
        Assert.assertNull(message1);

        // Wait, allow visible timeout to reach and move msg to front of q.
        try {
            Thread.sleep(1100);
        } catch (InterruptedException e) {
            // Ignore
        }

        // Verify there is now unprocessed message as expected.
        qmd = queueService.getQueueMetaData(qid);
        Assert.assertEquals(1, qmd.getTotalUnprocessedMessagesCount());
        Assert.assertEquals(0, qmd.getTotalInvisibleMessagesCount());

        // Receive message from q and verify it is same.
        Message secondMessage = queueService.receiveMessage(qid);
        queueService
                .deleteMessage(qid, secondMessage.getMessageReceiptHandle());
        Assert.assertNotNull(secondMessage);
        Assert.assertEquals(msgPayLoad, secondMessage.getMessagePayload());
        Assert.assertEquals(message.getMessageIdentifier(),
                secondMessage.getMessageIdentifier());
        Assert.assertNotSame(message.getMessageReceiptHandle(),
                secondMessage.getMessageReceiptHandle());

        qmd = queueService.getQueueMetaData(qid);
        Assert.assertEquals(0, qmd.getTotalUnprocessedMessagesCount());
        Assert.assertEquals(0, qmd.getTotalInvisibleMessagesCount());

    }

    @Test
    public void testParallelProducerConsumer() throws InterruptedException {
        logger.log("############### testParallelProducerConsumer ####################");
        QueueConfig queueConfig = new QueueConfig.QueueConfigBuilder()
                .withQueueName("Test-Q")
                .addAttribute(QueueAttributeKeys.VISIBILITY_TIMEOUT, "100")
                .build();
        // Create Queue
        Identifier qid = queueService.createQueue(queueConfig);
        Assert.assertNotNull(qid);

        // Msg Producer continuously in parallel produces messages
        MsgProducer msgProducer = new MsgProducer(queueService, qid);
        Thread thProducer = new Thread(msgProducer);
        // Msg consumer continuously in parallel consuming messages.
        MsgConsumer msgConsumer = new MsgConsumer(queueService, qid);
        Thread thConsumer = new Thread(msgConsumer);
        Thread threads[] = { thProducer, thConsumer };
        for (Thread th : threads) {
            th.start();
        }
        for (Thread th : threads) {
            th.join();
        }

        // Verify
        Assert.assertEquals(msgProducer.getMessagesProduced().size(),
                msgConsumer.getMessagesConsumed().size());
        for (Message message : msgProducer.getMessagesProduced()) {
            Assert.assertTrue(msgConsumer.getMessagesConsumed().contains(
                    message));
        }
    }

    private static class MsgProducer implements Runnable {
        private QueueService queueService;
        private Identifier qid;
        private Set<Message> messagesProduced;

        public MsgProducer(QueueService queueService, Identifier qid) {
            this.queueService = queueService;
            this.qid = qid;
            this.messagesProduced = new HashSet<Message>();
        }

        public Set<Message> getMessagesProduced() {
            return messagesProduced;
        }

        public void run() {
            for (int i = 0; i < 10; i++) {
                String msgPayLoad = "Test Message";
                Message message = new Message.MessageBuilder().withQueueId(qid)
                        .withMessagePayload(msgPayLoad).build();
                queueService
                        .sendMessage(new MessageSendRequest.MessageSendRequestBuilder()
                                .withMesage(message).withAttribute("k1", "v1")
                                .build());
                messagesProduced.add(message);
                // Sleep for some time before producing
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    // Ignore
                }
            }
        }
    }

    private static class MsgConsumer implements Runnable {
        private QueueService queueService;
        private Identifier qid;
        private Set<Message> messagesConsumed;

        public MsgConsumer(QueueService queueService, Identifier qid) {
            this.queueService = queueService;
            this.qid = qid;
            this.messagesConsumed = new HashSet<Message>();
        }

        public Set<Message> getMessagesConsumed() {
            return messagesConsumed;
        }

        public void run() {
            Message message = queueService.receiveMessage(qid);
            boolean stopConsuming = false;
            long timeStarted = System.currentTimeMillis();
            while (!stopConsuming) {
                if (message != null) {
                    // Consume and delete message
                    messagesConsumed.add(message);
                    queueService.deleteMessage(
                            message.getMessageQueueIdentifier(),
                            message.getMessageReceiptHandle());
                } else {
                    // Sleep for some time
                    try {
                        Thread.sleep(10);
                    } catch (InterruptedException e) {
                        // Ignore
                    }
                }
                message = queueService.receiveMessage(qid);
                if ((System.currentTimeMillis() - timeStarted) > 1000 * 5) {
                    stopConsuming = true;
                }
            }
            if (message != null) {
                messagesConsumed.add(message);
                queueService.deleteMessage(message.getMessageQueueIdentifier(),
                        message.getMessageReceiptHandle());
            }
        }
    }
}
