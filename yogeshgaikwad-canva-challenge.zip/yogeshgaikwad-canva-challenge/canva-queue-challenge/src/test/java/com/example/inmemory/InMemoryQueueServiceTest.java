package com.example.inmemory;

import org.junit.After;
import org.junit.Before;

import com.example.BaseQueueServiceTest;
import com.example.service.impl.inmemory.InMemoryQueueService;

/**
 * Runs all test defined in BaseQueueService test.
 */
public class InMemoryQueueServiceTest extends BaseQueueServiceTest {

    @Before
    public void before() {
        // Constructs In memory queue service
        queueService = new InMemoryQueueService();
    }

    @After
    public void after() {
        queueService.deleteAllQueues();
        queueService = null;
    }
}
