package com.example.inmemory;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.example.model.Identifier;
import com.example.model.message.Message;
import com.example.model.queue.QueueAttributeKeys;
import com.example.model.queue.QueueConfig;
import com.example.service.impl.inmemory.model.InMemoryQueue;

public class InMemoryQueueTest {

    private InMemoryQueue inMemoryQueue;

    @Before
    public void before() {
        inMemoryQueue = new InMemoryQueue(new QueueConfig.QueueConfigBuilder()
                .withQueueName("q1")
                .addAttribute(QueueAttributeKeys.VISIBILITY_TIMEOUT, "100")
                .build());
    }

    @Test
    public void testOfferPoll() {
        Message message = new Message.MessageBuilder()
                .withQueueId(new Identifier("q1"))
                .withMessagePayload("First Message").build();
        // Offer message
        inMemoryQueue.offer(message);

        // Poll message and verify
        Message messageRet = inMemoryQueue.poll();
        Assert.assertNotNull(messageRet);
        Assert.assertEquals(message, messageRet);

        // Poll again, should be null
        Message messageRet1 = inMemoryQueue.poll();
        Assert.assertNull(messageRet1);
    }

    @Test
    public void testOfferFirstPoll() {
        Message message = new Message.MessageBuilder()
                .withQueueId(new Identifier("q1"))
                .withMessagePayload("First Message").build();
        // Offer
        Assert.assertTrue(inMemoryQueue.offer(message));

        Message messageOfferFirst = new Message.MessageBuilder()
                .withQueueId(new Identifier("q1"))
                .withMessagePayload("Offer First Message").build();
        // Offer first
        Assert.assertTrue(inMemoryQueue.offerFirst(messageOfferFirst));

        // Verify poll returns the message added at first.
        Message messageRet = inMemoryQueue.poll();
        Assert.assertNotNull(messageRet);
        Assert.assertNotSame(message, messageRet);
        Assert.assertEquals(messageOfferFirst, messageRet);
    }

}
