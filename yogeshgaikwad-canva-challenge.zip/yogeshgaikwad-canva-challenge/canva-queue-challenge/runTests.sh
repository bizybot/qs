#!/bin/bash

for i in `seq 1 10`;
do
    mvn test > 'test-'$i'.log' &
    wait $!
done
