#!/bin/bash

CURRENT_DIR=$PWD

echo $CURRENT_DIR

MAVEN_PROJECT_CANVA_CHALLENGE=canva-queue-challenge
MAVEN_PROJECT_USE_QS=use-queue-service
MAVEN_PROJECT_FQ_VERIFY=fq-service-verifier

dir=$CURRENT_DIR'/'$MAVEN_PROJECT_CANVA_CHALLENGE
cd $dir
mvn clean package install javadoc:javadoc

dir=$CURRENT_DIR'/'$MAVEN_PROJECT_USE_QS
cd $dir
mvn clean package install

dir=$CURRENT_DIR'/'$MAVEN_PROJECT_FQ_VERIFY
cd $dir
mvn clean package install

cd $CURRENT_DIR

echo '----------------------------------------------------------------------'
echo 'RUNNING File based Queue service test with multiple JVMs'

DIR_NAME=ygtmp

rm -rf $DIR_NAME
mkdir $DIR_NAME

DB_DIR=$CURRENT_DIR'/'$DIR_NAME

echo $DB_DIR

# Start producer / consumer in JVM-1 which starts producing and consuming from Q.1
java -jar $MAVEN_PROJECT_USE_QS/target/use-queue-service-1.0.jar $DB_DIR 55 125 p2 50 &

PID_JVM_1=$!
echo 'JVM 1 - PID='$PID_JVM_1

# Start producer / consumer in JVM-2 which starts producing and consuming from Q.1
java -jar $MAVEN_PROJECT_USE_QS/target/use-queue-service-1.0.jar $DB_DIR 0 45 p1 50 &

PID_JVM_2=$!
echo 'JVM 2 - PID='$PID_JVM_2

echo 'Waiting for JVMs to complete and exit'
wait $PID_JVM_1
wait $PID_JVM_2

echo '##################################################################    Verifying    #####################################################'

java -jar $MAVEN_PROJECT_FQ_VERIFY/target/fq-service-verifier-1.0.jar $DB_DIR p1 p2


echo 'DONE'

